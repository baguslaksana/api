<?php

namespace App\Http\Controllers\Api;

use App\Models\Layanan;
use App\Models\Formulir;
use App\Models\Berita;
use App\Http\Controllers\Controller;
use App\Http\Resources\FiturResource;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class FiturController extends Controller
{
    public function layanan()
    {
        $layanan = Layanan::all();

        return new FiturResource(true, 'List Data Layanan', $layanan);
    }

    public function berita()
    {
        $berita = Berita::select('judul_berita','foto_berita', 'isi_berita')
        ->selectRaw('DATE_FORMAT(tgl_berita, "%d/%m/%Y %H:%i") as tgl_berita')
        ->orderBy('tgl_berita', 'desc')
        ->get();

        foreach ($berita as $item) {
            $item->foto_berita = base64_encode($item->foto_berita);
        }

        return new FiturResource(true, 'List Data Berita', $berita);
    }

    public function getFormulirByLayanan($id_layanan)
    {
        $formulir = Formulir::where('id_layanan', $id_layanan)->get();

        if ($formulir->isEmpty()) {
            return new FiturResource(false, 'Formulir tidak ditemukan untuk id_layanan ini', []);
        }

        foreach ($formulir as $item) {
            $item->data_formulir = json_decode($item->data_formulir);
        }

        return new FiturResource(true, 'Formulir ditemukan', $formulir);
    }

    public function kirimPengajuan(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'nama_lengkap' => 'required|string',
            'keterangan' => 'required|string',
        ]);
    
        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 400);
        }
    
        $formulir = Formulir::create([
            'nama_lengkap' => $request->nama_lengkap,
            'alamat' => $request->alamat,
        ]);
    
        return response()->json(['message' => 'Data formulir berhasil dikirim'], 201);
    }    
}
