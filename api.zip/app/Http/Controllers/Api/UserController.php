<?php

namespace App\Http\Controllers\Api;

use App\Models\Penduduk;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class UserController extends Controller
{
    public function createUser(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'nama_lengkap' => 'required',
                'email' => 'required|email|unique:penduduk,email',
                'password' => 'required|min:8',
                'no_hp' => 'required',
                'jenis_kelamin' => 'nullable',
                'tanggal_lahir' => 'nullable|date', 
                'kebangsaan' => 'nullable', 
                'pekerjaan' => 'nullable', 
                'golongan_darah' => 'nullable', 
                'status_nikah' => 'nullable', 
                'photo_profil' => 'nullable', 
                'username' => 'nullable',
                'nik' => 'nullable', 
                'alamat' => 'nullable',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'status' => false,
                    'message' => 'Validation error',
                    'errors' => $validator->errors()
                ], 422);
            }

            $penduduk = new Penduduk();
            $penduduk->nama_lengkap = $request->nama_lengkap;
            $penduduk->email = $request->email;
            $penduduk->password = Hash::make($request->password);
            $penduduk->no_hp = $request->no_hp;
            $penduduk->jenis_kelamin = $request->jenis_kelamin; // tambahan
            $penduduk->tanggal_lahir = $request->tanggal_lahir; // tambahan
            $penduduk->kebangsaan = $request->kebangsaan; // tambahan
            $penduduk->pekerjaan = $request->pekerjaan; // tambahan
            $penduduk->golongan_darah = $request->golongan_darah; // tambahan
            $penduduk->status_nikah = $request->status_nikah; // tambahan
            $penduduk->foto_profil = $request->photo_profil; // tambahan
            $penduduk->username = $request->username; // tambahan
            $penduduk->nik = $request->nik; // tambahan
            $penduduk->alamat = $request->alamat;
            $penduduk->save();

            return response()->json([
                'status' => true,
                'message' => 'User Created Successfully',
                'user' => $penduduk
            ], 201);
        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => 'Failed to create user',
                'error' => $th->getMessage()
            ], 500);
        }
    }

    public function loginUser(Request $request)
    {
        try {
            $validateUser = Validator::make($request->all(), [
                'email' => 'required|email',
                'password' => 'required'
            ]);

            if ($validateUser->fails()) {
                return response()->json([
                    'status' => false,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 422);
            }

            if (!Auth::attempt($request->only(['email', 'password']))) {
                return response()->json([
                    'status' => false,
                    'message' => 'Email & Password does not match with our record.',
                ], 401);
            }

            $user = Penduduk::where('email', $request->email)->first();

            return response()->json([
                'status' => true,
                'message' => 'User Logged In Successfully',
                'token' => $user->createToken("API TOKEN")->plainTextToken
            ], 200);
        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }

    public function updateUserPassword(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'email' => 'required|email',
                'password' => 'required|min:8',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'status' => false,
                    'message' => 'Validation error',
                    'errors' => $validator->errors()
                ], 422);
            }

            $user = Penduduk::where('email', $request->email)->first();

            if (!$user) {
                return response()->json([
                    'status' => false,
                    'message' => 'User not found',
                ], 404);
            }

            $user->password = Hash::make($request->password);
            $user->save();

            return response()->json([
                'status' => true,
                'message' => 'Password updated successfully',
            ], 200);
        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => 'Failed to update password',
                'error' => $th->getMessage()
            ], 500);
        }
    }

    public function updateUser(Request $request)
    {
        try {
            $user = Auth::user();
    
            if (!$user) {
                return response()->json([
                    'status' => false,
                    'message' => 'User not found',
                ], 404);
            }
    
            Penduduk::where('email', $user->email)->update([
                'nama_lengkap' => $request->nama_lengkap,
                'username' => $request->username,
                'email' => $request->email,
                'no_hp' => $request->no_hp,
                'alamat' => $request->alamat,
                'jenis_kelamin' => $request->jenis_kelamin,
                'tanggal_lahir' => $request->tanggal_lahir,
                'kebangsaan' => $request->kebangsaan,
                'pekerjaan' => $request->pekerjaan,
                'status_nikah' => $request->status_nikah,
                'nik' => $request->nik,
            ]);
    
            return response()->json([
                'status' => true,
                'message' => 'User data updated successfully',
                'user' => $user
            ], 200);
        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => 'Failed to update user data',
                'error' => $th->getMessage()
            ], 500);
        }
    }
    

    public function getUserFromToken()
    {
        $user = Auth::user();

        if ($user) {
            return response()->json([
                'id' => $user->id,
                'nama_lengkap' => $user->nama_lengkap,
                'username' => $user->username,
                'email' => $user->email,
                'no_hp' => $user->no_hp,
                'alamat' => $user->alamat,
                'jenis_kelamin' => $user->jenis_kelamin,
                'tanggal_lahir' => $user->tanggal_lahir,
                'kebangsaan' => $user->kebangsaan,
                'pekerjaan' => $user->pekerjaan,
                'status_nikah' => $user->status_nikah,
                'nik' => $user->nik,
            ]);
        } else {
            return response()->json(['error' => 'User not found'], 404);
        }
    }
}
