<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class User extends Model
{
    protected $fillable = [
        'id', 
        'nama_lengkap', 
        'username', 
        'email', 
        'no_hp', 
        'alamat', 
        'jenis_kelamin', 
        'tanggal_lahir', 
        'kebangsaan',
        'pekerjaan',
        'golongan_darah',
        'status_nikah',
        'nik',
    ];
}
